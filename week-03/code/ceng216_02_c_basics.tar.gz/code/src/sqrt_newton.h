#ifndef SQRT_NEWTON_H
#define SQRT_NEWTON_H

double sqrt_newton(double y, double tol);

#endif
