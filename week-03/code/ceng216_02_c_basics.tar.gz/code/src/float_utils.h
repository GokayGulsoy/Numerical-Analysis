


#ifndef FLOAT_UTILS_H
#define FLOAT_UTILS_H

void print_hex(double d);
void print_bin(double d);

#endif
